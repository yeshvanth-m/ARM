# Cmake package for MDK

## Requirements:
- Cmake v3.6 or newer
- Ninja build system
- Keil, GCC, or Clang
- CMSIS header files

## Tested toolchains
- ARMClang - Arm compiler v6
- ARMCC    - Arm compiler v5
- ARM-None-eabi-gcc - GCC compiler for Arm targets
- Clang/LLVM with GCC supporting libraries
    - Requires the correct GCC flavor (Arm-none-eabi) to be installed and detectable as well

## Contents
- cmake/nrfmdk.cmake : Entrypoint cmake file.
- cmake/toolchain.cmake : Selects and initializes the compiler and linker toolchains.
- cmake/target.cmake : Selects and initializes the target properties. 
- cmake/example : An example cmake list that describes a simple example using a main.c file and the MDK.
- cmake/mdkDependentOptionList.cmake : A utility class implementing a one-liner for multiple-choice cmake options.

## To prepare your project folder:
We'll call your project folder `root_dir`.
1. Place the MDK source files in your project directory under the folder `root_dir/mdk/`.
2. Copy the example files from `root_dir/mdk/example` to `root_dir/`.
3. The MDK will automatically download CMSIS for you from github. If you want to use a specific version, either set `MDK_CMSIS_VERSION` to your requested tag, or download the CMSIS pack and set `CMSIS_DIR` to point to its location.

## To build your project:
1. Generate Ninja build scripts using `cmake . -G Ninja -DMDK_TARGET_SOC=nrf5340_xxaa -DMDK_TARGET_CORE=network`
    - The most important variables:
        - `MDK_TARGET_SOC`        : The SOC to build for, e.g. `nrf5340_xxaa` or `nrf52832_xxaa`
        - `MDK_TARGET_CORE`       : Used if the SOC is a multi-core device, the core to build for. 
                                        Defaults to `application`, see the related device file under `mdk/cmake/device/<device>.cmake` for possible values.
        - `MDK_TOOLCHAIN`         : The toolchain to build with. Defaults to `gcc`; `armcc`, `gcc`, and `clang` are supported.
        - `CMSIS_CORE_INCLUDE_DIR` : Folder that includes common header files for ARM processors.
        - For more variables see ccmake or cmake-gui.
        - Note that variables that impact compiler flags must be set before the `project()` command, or must be passed on the command line.
2. Build the executable using `cmake --build . --config Debug`

## Generating hex files
The method create_hex exposed by the mdk toolchain file allows you to generate hex files for use in programming tools. By default it creates a hex file with the same name as your output elf file (typically the name of your target executable), but you can override this by passing the requested name (without file extension) as the second argument to create_hex.

create_hex(exe) # Creates <exe.elf_directory>/exe.hex
create_hex(exe, another_hex_file_name) # Creates <exe.elf_directory>/another_hex_file_name.hex